sap.ui.define([
	"employees/controller/BaseController"
], function(
	BaseController
) {
	"use strict";

	return BaseController.extend("employees.controller.App", {
        onInit: function () {
            
        }
	});
});