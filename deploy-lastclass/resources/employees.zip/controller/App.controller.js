sap.ui.define(["employees/controller/BaseController"],function(e){"use strict";return e.extend("employees.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map